// italian translation by raf

var fdLocale = {
        months:[ "Gennaio", "Febbraio", "Marzo", "Aprile", "Maggio", "Giugno", "Luglio", "Agosto", "Settembre", "Ottobre", "Novembre", "Dicembre" ],
        fullDay:[ "Luned\u00ec", "Marted\u00ec", "Mercoled\u00ec", "Gioved\u00ec", "Venerd\u00ec", "Sabato", "Domenica" ],
        /*
        Only stipulate the dayAbbr should the first letter of the fullDay not suffice
        dayAbbr:[],
        Only stipulate the firstDayOfWeek should the first day not be Monday
        firstDayOfWeek:0,
        */
        titles:[ "Mese Precedente", "Mese Successivo", "Anno Precedente", "Anno Successivo", "Oggi" ]
};
